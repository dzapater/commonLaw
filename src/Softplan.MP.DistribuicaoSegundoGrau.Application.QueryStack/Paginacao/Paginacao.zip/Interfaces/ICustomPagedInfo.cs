﻿namespace Softplan.MP.DistribuicaoSegundoGrau.Application.QueryStack.Paginacao.Interfaces
{
    public interface ICustomPagedInfo
    {
        ICustomPageInfo PageInfo { get; set; }
    }
}